package com.nexus.facedetect

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity() {
 private lateinit var preview: PreviewView; private lateinit var overlay: FaceOverlay
 private lateinit var status: TextView; private lateinit var count: TextView; private lateinit var rate: TextView
 private lateinit var toggle: Button; private lateinit var cameraBtn: Button; private lateinit var flashBtn: Button
 private val executor = Executors.newSingleThreadExecutor(); private val busy = AtomicBoolean(false)
 private var provider: ProcessCameraProvider? = null; private var camera: Camera? = null
 private var lens = CameraSelector.LENS_FACING_BACK; private var running = true; private var torch = false
 private var frames = 0; private var lastRate = System.currentTimeMillis()
 private val detector by lazy { FaceDetection.getClient(FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST).setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL).setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL).enableTracking().build()) }
 private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) startCamera() else status.text = "Kamerazugriff verweigert – Berechtigung in Android erlauben." }
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); buildUi(); if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera() else permission.launch(Manifest.permission.CAMERA) }
 private fun buildUi() {
  val root = LinearLayout(this).apply { orientation = 1; setPadding(14,14,14,10); setBackgroundColor(Color.rgb(8,11,20)) }
  root.addView(TextView(this).apply { text="NEXUS FACE DETECT"; textSize=22f; gravity=Gravity.CENTER; setTextColor(Color.rgb(0,229,255)); setTypeface(null,1) })
  root.addView(TextView(this).apply { text="Lokale Gesichtserkennung · keine Identifizierung"; textSize=12f; gravity=Gravity.CENTER; setTextColor(Color.LTGRAY); setPadding(0,5,0,10) })
  preview = PreviewView(this).apply { implementationMode=PreviewView.ImplementationMode.COMPATIBLE; scaleType=PreviewView.ScaleType.FILL_CENTER }
  overlay = FaceOverlay(this)
  val frame = FrameLayout(this).apply { addView(preview, FrameLayout.LayoutParams(-1,-1)); addView(overlay, FrameLayout.LayoutParams(-1,-1)) }
  root.addView(frame, LinearLayout.LayoutParams(-1,0,1f))
  count = label("Erkannte Gesichter: 0"); rate = label("Analyse: startet …"); status = label("Kamerastatus: wartet")
  root.addView(count); root.addView(rate); root.addView(status)
  val row = LinearLayout(this).apply { gravity=Gravity.CENTER }
  toggle = button("Erkennung stoppen") { running = !running; toggle.text=if(running) "Erkennung stoppen" else "Erkennung starten"; if(!running){overlay.clear(); count.text="Erkannte Gesichter: 0"; status.text="Erkennung pausiert"} }
  cameraBtn = button("Kamera wechseln") { lens=if(lens==CameraSelector.LENS_FACING_BACK) CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK; torch=false; provider?.let { bind(it) } }
  flashBtn = button("Licht an/aus") { val c=camera; if(c==null || !c.cameraInfo.hasFlashUnit()) Toast.makeText(this,"Kein Blitz für diese Kamera",Toast.LENGTH_SHORT).show() else { torch=!torch; c.cameraControl.enableTorch(torch); flashBtn.text=if(torch) "Licht aus" else "Licht an/aus" } }
  row.addView(toggle,LinearLayout.LayoutParams(0,-2,1f)); row.addView(cameraBtn,LinearLayout.LayoutParams(0,-2,1f)); row.addView(flashBtn,LinearLayout.LayoutParams(0,-2,1f)); root.addView(row)
  root.addView(TextView(this).apply { text="Datenschutz: Bilder werden nicht gespeichert oder hochgeladen."; textSize=11f; gravity=Gravity.CENTER; setTextColor(Color.GRAY); setPadding(0,8,0,0) })
  setContentView(root)
 }
 private fun label(s:String)=TextView(this).apply{text=s;textSize=13f;setTextColor(Color.WHITE);setPadding(2,5,2,2)}
 private fun button(s:String, action:()->Unit)=Button(this).apply{text=s;textSize=10f;setTextColor(Color.WHITE);backgroundTintList=android.content.res.ColorStateList.valueOf(Color.rgb(82,52,160));setOnClickListener{action()}}
 private fun startCamera(){ val f=ProcessCameraProvider.getInstance(this); f.addListener({ try { provider=f.get(); bind(provider!!) } catch(e:Exception){status.text="Kamera konnte nicht gestartet werden"} },ContextCompat.getMainExecutor(this)) }
 private fun bind(p:ProcessCameraProvider){ try {
  val selector=CameraSelector.Builder().requireLensFacing(lens).build()
  val pv=Preview.Builder().build().also{it.setSurfaceProvider(preview.surfaceProvider)}
  val analysis=ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).setTargetResolution(android.util.Size(640,480)).build()
  analysis.setAnalyzer(executor){ proxy -> if(!running || !busy.compareAndSet(false,true)){proxy.close();return@setAnalyzer}; val image=proxy.image
   if(image==null){proxy.close();busy.set(false);return@setAnalyzer}
   detector.process(InputImage.fromMediaImage(image,proxy.imageInfo.rotationDegrees)).addOnSuccessListener { faces -> if(running){overlay.update(faces,proxy.width,proxy.height,proxy.imageInfo.rotationDegrees,lens);count.text="Erkannte Gesichter: ${faces.size}";val face=faces.firstOrNull();status.text=if(face==null) "Keine Gesichter erkannt" else "Kopfwinkel: ${face.headEulerAngleY.toInt()}° / ${face.headEulerAngleZ.toInt()}°"+(face.smilingProbability?.let{" · Lächeln: ${(it*100).toInt()}%"}?:"");frames++;val now=System.currentTimeMillis();if(now-lastRate>=1000){rate.text="Analysierte Bilder: $frames/s";frames=0;lastRate=now}} }.addOnFailureListener{runOnUiThread{status.text="Analysefehler: ${it.localizedMessage ?: "unbekannt"}"}}.addOnCompleteListener{proxy.close();busy.set(false)}
  }
  p.unbindAll(); camera=p.bindToLifecycle(this,selector,pv,analysis);overlay.setLens(lens);status.text="Kamera aktiv"
 }catch(e:Exception){status.text="Kamera nicht verfügbar";Toast.makeText(this,e.localizedMessage ?: "Kamerafehler",Toast.LENGTH_LONG).show()} }
 override fun onResume(){super.onResume();if(::status.isInitialized && provider==null && ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)startCamera()}
 override fun onDestroy(){running=false;provider?.unbindAll();executor.shutdown();detector.close();super.onDestroy()}
}
