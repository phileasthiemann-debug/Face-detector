package com.nexus.facedetect

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import androidx.camera.core.CameraSelector
import com.google.mlkit.vision.face.Face
import kotlin.math.max

class FaceOverlay(context: Context) : View(context) {
 private val box=Paint(3).apply{color=Color.rgb(0,229,255);style=Paint.Style.STROKE;strokeWidth=4f}
 private val dot=Paint(3).apply{color=Color.rgb(124,77,255);style=Paint.Style.FILL}
 private val text=Paint(3).apply{color=Color.WHITE;textSize=30f;setShadowLayer(5f,1f,1f,Color.BLACK)}
 @Volatile private var faces:List<Face> = emptyList(); @Volatile private var iw=1; @Volatile private var ih=1; @Volatile private var lens=CameraSelector.LENS_FACING_BACK
 fun setLens(v:Int){lens=v;invalidate()}
 fun clear(){faces=emptyList();invalidate()}
 fun update(f:List<Face>,w:Int,h:Int,rotation:Int,l:Int){faces=f.toList();iw=if(rotation%180==0)w else h;ih=if(rotation%180==0)h else w;lens=l;postInvalidate()}
 override fun onDraw(c:Canvas){super.onDraw(c);if(iw<=1||ih<=1)return;val scale=max(width.toFloat()/iw,height.toFloat()/ih);val dx=(width-iw*scale)/2f;val dy=(height-ih*scale)/2f
  faces.forEachIndexed{i,face->val r=face.boundingBox;var left=r.left*scale+dx;var right=r.right*scale+dx;val top=r.top*scale+dy;val bottom=r.bottom*scale+dy;if(lens==CameraSelector.LENS_FACING_FRONT){val l=width-right;right=width-left;left=l};c.drawRoundRect(RectF(left,top,right,bottom),12f,12f,box);c.drawText("GESICHT ${i+1}",left,max(32f,top-8f),text);face.allLandmarks.forEach{p->var x=p.position.x*scale+dx;if(lens==CameraSelector.LENS_FACING_FRONT)x=width-x;c.drawCircle(x,p.position.y*scale+dy,5f,dot)}}
 }
}
