# NEXUS FACE DETECT

Android-Projekt mit Kotlin, CameraX und Google ML Kit Face Detection.

## Funktionen
- Live-Kameravorschau, Front-/Rückkamera-Wechsel
- Gesichtsrahmen und ML-Kit-Landmark-Punkte
- Anzahl erkannter Gesichter, Kopfwinkel und sofern verfügbar Lächelindikator
- Taschenlampe, wenn die gewählte Kamera sie unterstützt
- `STRATEGY_KEEP_ONLY_LATEST` verhindert eine anwachsende Analyse-Warteschlange
- Keine absichtliche Speicherung oder Übertragung der Kamerabilder

## APK bauen
Benötigt JDK 17, Android SDK Platform 35, Android Build Tools und Internet beim ersten Abhängigkeitsdownload.

Im Projektordner ausführen:

```bash
gradle assembleDebug
```

Die Debug-APK liegt bei erfolgreichem Build unter `app/build/outputs/apk/debug/app-debug.apk`.
Mit ADB installieren: `adb install -r app/build/outputs/apk/debug/app-debug.apk`.

In Termux müssen Android SDK, Platform 35 und Build Tools korrekt eingerichtet sein. Diese Projektübergabe wurde hier nicht mit Gradle kompiliert; die APK-Erstellung ist daher nicht als erfolgreich getestet bestätigt.

## Grenzen
Diese App erkennt Positionen von Gesichtern, nicht die Identität einer Person. Bildrate ist die Zahl der analysierten Bilder pro Sekunde, keine garantierte Kamera-FPS. Overlay-Skalierung, Spiegelung und Rotation müssen auf dem Zielgerät getestet werden. Ein separater Startbildschirm und eine ausführliche Einstellungsseite sind in dieser ersten Version noch nicht enthalten.
